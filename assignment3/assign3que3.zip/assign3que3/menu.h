#ifndef MENU_H
#define MENU_H


enum Vmenu{EXIT,SET,GET};
Vmenu menu();
#endif;